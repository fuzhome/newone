
import os

text = os.popen("print('Something printed')").read()

print(text)
