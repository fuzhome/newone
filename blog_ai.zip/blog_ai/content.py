
from random import randint
import json
from wix_image import upload_to_wix
ai_content_list = [{'title': " J.J. McCarthy: The Rise of Michigan's New Quarterback"}, {'description': ''}, {'description': 'J.J. McCarthy, the sophomore quarterback for the University of Michigan Wolverines, has captured the attention of college football fans across the nation.  His dynamic playmaking ability and leadership on the field have propelled Michigan to new heights, igniting hope for a national championship run. '}, {'description': ''}, {'sub-heading': '1. A Star in the Making:'}, {'description': ''}, {'description': 'McCarthy, a native of Nazareth, Pennsylvania, arrived in Ann Arbor as a highly touted five star recruit in the 2021 class.  He was the highest ranked quarterback prospect in the state of Michigan and was considered one of the top quarterback prospects in the nation.  While he saw limited action during his freshman year, he impressed with his athleticism, arm strength, and quick decision making.'}, {'description': ''}, {'sub-heading': '2. Seizing the Opportunity:'}, {'description': ''}, {'description': "The 2022 season saw McCarthy take the reins as the starting quarterback, replacing Cade McNamara who had led the Wolverines to a Big Ten Championship the previous year.  McCarthy's early struggles were met with criticism, but he quickly silenced his detractors. His ability to extend plays with his legs, find open receivers downfield, and make crucial throws under pressure proved invaluable for the Wolverines."}, {'description': ''}, {'sub-heading': '3. Leading Michigan to a Historic Season:'}, {'description': ''}, {'description': "McCarthy's leadership and playmaking ability were on full display throughout the 2022 season. He led Michigan to a perfect 13 0 regular season, earning the Wolverines a spot in the College Football Playoff for the second consecutive year.  His performance in the playoff semifinal game against TCU, where he threw for 343 yards and three touchdowns, was a testament to his growth and development."}, {'description': ''}, {'sub-heading': '4. The Future is Bright:'}, {'description': ''}, {'description': "The 2023 season is shaping up to be a pivotal year for McCarthy and the Wolverines.  With a year of starting experience under his belt and a talented supporting cast surrounding him, McCarthy is poised to lead the Wolverines to even greater heights.  His ability to learn from his mistakes, improve his accuracy, and continue to develop his leadership skills will be crucial for the Wolverines' success."}, {'description': ''}, {'sub-heading': '5. A Leader on and off the Field:'}, {'description': ''}, {'description': 'Beyond his on field contributions, McCarthy is recognized for his leadership and character off the field. He is known for his humility, work ethic, and commitment to his teammates.  He has also shown a willingness to embrace his role as a leader, inspiring his teammates and representing the program with integrity.'}, {'description': ''}, {'sub-heading': '6.  A National Stage:'}, {'description': ''}, {'description': "With the attention of the nation focused on Michigan's quarterback, J.J. McCarthy is well on his way to establishing himself as one of the premier quarterbacks in college football.  His ability to perform under pressure, lead by example, and constantly improve has earned him the respect of coaches, teammates, and fans alike. The future is bright for J.J. McCarthy and the University of Michigan, and the nation is eagerly awaiting what he will accomplish in the years to come. "}, {'description': ''}]


def get_rich_content_node_list(trending_keyword,image_url,ai_content_list):
  image_id = upload_to_wix(image_url)
  first_content_list = [
      {
            "type": "PARAGRAPH",
            "id": "1space",
            "nodes": [],
            "paragraphData": {}
          },
          {
            "type": "IMAGE",
            "id": "2image",
            "nodes": [],
            "imageData": {
              "containerData": {
                "width": {
                  "custom": "368"
                },
                "alignment": "CENTER"
              },
              "image": {
                "src": {
                  "id": image_id
                },
                "width": 474,
                "height": 266
              },
              "altText": trending_keyword
            }
          },
          {
            "type": "PARAGRAPH",
            "id": "2space",
            "nodes": [],
            "paragraphData": {}
          },
          {
            "type": "PARAGRAPH",
            "id": "3space",
            "nodes": [],
            "paragraphData": {}
          }
  ]


  content_list = []

  for content in ai_content_list:
      
      try:
          if content['title']:
              continue
      except:
          try:
              content_list.append({
            "type": "HEADING",
            "id": str(randint(1,90)),
            "nodes": [
              {
                "type": "TEXT",
                "id": "",
                "nodes": [],
                "textData": {
                  "text": content["sub-heading"],
                  "decorations": []
                }
              }
            ],
            "headingData": {
              "level": 4,
              "textStyle": {
                "textAlignment": "AUTO"
              }
            }
          })
          except:
              content_list.append({
            "type": "PARAGRAPH",
            "id": str(randint(1,90)),
            "nodes": [
              {
                "type": "TEXT",
                "id": "",
                "nodes": [],
                "textData": {
                  "text": content["description"],
                  "decorations": []
                }
              }
            ],
            "paragraphData": {
              "textStyle": {
                "textAlignment": "AUTO"
              }
            }
          })
  
  final_content_list = first_content_list + content_list

  all_contents_list = json.dumps(final_content_list)

  #print(all_contents_list)
  return all_contents_list
