import requests
from requests.structures import CaseInsensitiveDict

url = "https://dev.wix.com/docs/api/v1/generate-token/test-token"

headers = CaseInsensitiveDict()
headers["accept"] = "application/json, text/plain, */*"
headers["accept-encoding"] = "gzip, deflate, br, zstd"
headers["accept-language"] = "en-US,en;q=0.9,en-IN;q=0.8"
headers["content-length"] = "53"
headers["Content-Type"] = "application/json"
headers["cookie"] = "is_edit_mode=false; is_edit_mode_first=false; _wixCIDX=5f334436-5d86-4fec-ae52-dd59acb6ee26; _gcl_au=1.1.773980607.1717999648; wixLanguage=en; userType=REGISTERED; _wixUIDX=1620614060|09db6a28-ccad-4fb9-8472-31d63fe5f589; _wixAB3=3524517#1|3533917#1; XSRF-TOKEN=1723790717|FGnGLzRPM02w; _wix_browser_sess=88bec49b-cd12-4a1e-b826-7a5f15c89295; _gid=GA1.2.246577923.1723845824; _ga=GA1.1.2098230370.1717999648; _wixAB3|09db6a28-ccad-4fb9-8472-31d63fe5f589=287210#2|357145#4|357146#4|567711#1|1021294#2|1469848#1|1943797#1|2155681#3|2207098#1|2323055#1|2798171#2|2903222#2|3031450#1|3043490#2|3073401#2|3085513#2|3090837#2|3100825#1|3104994#1|3107856#1|3121046#2|3125751#2|3171904#2|3236281#2|3251411#2|3252247#1|3263621#1|3275040#2|3309945#1|3317683#1|3328396#2|3367453#1|3372952#2|3386458#2|3408588#1|3444566#1|3446613#1|3452340#1|3472808#1|3479175#1|3479290#1|3480964#1|3484362#1|3485600#1|3493362#2|3494312#1|3498019#1|3498120#2|3504511#2|3504640#1|3505802#1|3505823#1|3520022#1|3520205#2|3520259#1|3521310#2|3523116#2|3524439#2|3524449#3|3525456#2|3525690#2|3527405#1|3527641#2|3528922#2|3532241#2|3534109#1|3536821#2|3541791#2|3542609#2|3543018#2|3543101#1|3543678#2|3543791#2|3543830#2|3543960#1|3545582#1|3546211#1|3547528#1|3548334#1|3549879#2|3551199#2|3551747#2|3554125#2|3554431#1|3554618#1; wixSession2=JWT.eyJraWQiOiJrdU42YlJQRCIsImFsZyI6IlJTMjU2In0.eyJkYXRhIjoie1widXNlckd1aWRcIjpcIjA5ZGI2YTI4LWNjYWQtNGZiOS04NDcyLTMxZDYzZmU1ZjU4OVwiLFwidXNlck5hbWVcIjpcImhlbG92ZWo5XCIsXCJjb2xvcnNcIjp7fSxcInVjZFwiOlwiMjAyNC0wMy0zMVQxNjoxOTozOS4wMDArMDA6MDBcIixcInd4c1wiOmZhbHNlLFwiZXd4ZFwiOmZhbHNlLFwiYW9yXCI6dHJ1ZSxcImFjaVwiOlwiMDlkYjZhMjgtY2NhZC00ZmI5LTg0NzItMzFkNjNmZTVmNTg5XCIsXCJybWJcIjp0cnVlLFwibHZsZFwiOlwiMjAyNC0wOC0xNlQyMzoyNDoyOS41NjMrMDA6MDBcIixcImxhdGhcIjpcIjIwMjQtMDgtMDhUMTE6MDI6NTYuOTk0KzAwOjAwXCIsXCJ3eGV4cFwiOlwiMjAyNC0wOC0zMFQxMTowMjo1Ny4wODErMDA6MDBcIixcInBhY1wiOnRydWUsXCJzaWRcIjpcImM3NTQ1MjBiLTkwNTAtNGNhYS04NTc1LTQ2ZWUwY2NkNjBhMVwifSIsImlhdCI6MTcyMzg1MDY2OSwiZXhwIjoxNzI1MDE1Nzc3fQ.kgZA178DM7d3WuS8jjJT7Go0z3Ular0Trl6iwCMila7UIDG_ycP3-EKSaSO1MyJpUzILUWwwS-tqjTgF2yj4u0tq7MtHA27_Ag2xROXg8cJtW3M7WTTiGeFzBVBoj3ZKM7C8YbslapDwoE31ei2Tp6mezb8Poh90l3eQlMq3ovtp5Ee7qOygp5kqwL0uB9jswHWty7u9uwMFOcJ3-Z4eJNaJP4J4_tah9Zla5pVOmAoqyctXlwW31mQ197UAoxv7HSW0b6nXjhR1HJpdAfSxOiUHmVKXG73SD6Z1nL-RCXs9UzHs5fu7UjhQUKXfAMWr1bYW40-tjsR55x4TpvjsRg; wixClient=helovej9||VERIFIED_OPT_IN|0|1723850669565|1725015776565|09db6a28-ccad-4fb9-8472-31d63fe5f589|{}|wix|09db6a28-ccad-4fb9-8472-31d63fe5f589"
headers["origin"] = "https://dev.wix.com"
headers["priority"] = "u=1, i"
headers["referer"] = "https://dev.wix.com/docs/rest/assets/media/media-manager/files/import-file"
headers["user-agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0"
headers["x-wix-client-artifact-id"] = "nextjs-template"
headers["x-xsrf-token"] = "1723790717|FGnGLzRPM02w"

data = '{"metaSiteId":"ac0a1a1f-239a-4262-a359-8c7f75e282d2"}'

def create_token():
    resp = requests.post(url, headers=headers, data=data)
    token = resp.json()["token"]
    return token

#print(create_token())