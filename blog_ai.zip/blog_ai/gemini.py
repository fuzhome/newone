"""
Install the Google AI Python SDK

$ pip install google-generativeai
"""
import google.generativeai as genai


def load_ai(api_key):
   genai.configure(api_key=api_key)

   # Create the model
   generation_config = {
   "temperature": 1,
   "top_p": 0.95,
   "top_k": 64,
   "max_output_tokens": 8192,
   "response_mime_type": "text/plain",
   }

   model = genai.GenerativeModel(
   model_name="gemini-1.5-flash",
   generation_config=generation_config,
   # safety_settings = Adjust safety settings
   # See https://ai.google.dev/gemini-api/docs/safety-settings
   )

   chat_session = model.start_chat(
   history=[
   ]
   )
   return chat_session

def get_ai_content(topic_keyword):
  ai = load_ai("AIzaSyAclssvGGdPw6Nbj92VsG7D7Wc4eG8MCDo")

  #request_it = chat_session.send_message
  text_in_it = f"Generate a news blog post on this current trending topic '{topic_keyword}' by gathering information from the internet in 1000 words having 5 to 6 sub-points and no additional information. News blog post Language should be in the current trending topic's language. If it is in english then content should be in english, if it's in different language then content should be in that language."
  
  try:
     #response = request_it(text_in_it)
     response = ai.send_message(f"Generate a news blog post on this current trending topic '{topic_keyword}' by gathering information from the internet in 1000 words having 5 to 6 sub-points and no additional information. News blog post Language should be in the current trending topic's language. If it is in english then content should be in english, if it's in different language then content should be in that language.")
     return return_function(response,ai)
  except:
     try:
         #print("Got here")
         ai2 = load_ai("AIzaSyCbx21NQ2FJMO8y_XZsFJYfvo_JbiNI_ZU")
         #print("loaded another ai")
         response = ai2.send_message(text_in_it)
         #print("Above Success")
         #print(response.text)
         #exit()
         return return_function(response,ai2)
     except:
         try:
            #print("Got here2")
            ai3 = load_ai("AIzaSyBIAxvmIobjEOqQzO2WHmGB4T0O4mcFpn0")
            response = ai3.send_message(text_in_it)
            return return_function(response,ai3)
         except:
            try:
               #print("Got here3")
               ai4 = load_ai("AIzaSyCRyiVDA_Xo2lmmhu8-VuefCCauH_ji8ek")
               response = ai4.send_message(text_in_it)
               return return_function(response,ai4)
            except:
               try:
                  #print("Got here4")
                  ai5 = load_ai("AIzaSyDaLKiCeh5_Fx0Qv0k44ZqGFy9-MqC6Ruc")
                  response = ai5.send_message(text_in_it)
                  return return_function(response,ai5)
               except:
                  try:
                     #print("Got here5")
                     ai6 = load_ai("AIzaSyCOUQMNA3_irc1OIuEwOSzc_So5OzzTwuw")
                     response = ai6.send_message(text_in_it)
                     return return_function(response,ai6)
                  except:
                     try:
                        #print("Got here6")
                        ai7 = load_ai("AIzaSyDJK1cO0pxoRr2ZF6CGWJ31WfsfkLbcfsU")
                        response = ai7.send_message(text_in_it)
                        return return_function(response,ai7)
                     except:
                        pass


  #response = chat_session.send_message(f"Generate a news blog post on this current trending topic '{topic_keyword}' by gathering information from the internet in 1000 words having 5 to 6 sub-points and no additional information.")

  #text_content = response.text.replace('##', '').replace('**', '').replace('-','')

  #lines = text_content.split('\n')

def return_function(response,loaded_ai):
   text_lines = response.text.replace("-"," ").split("\n")
   text_content = []

   for text in text_lines:
      if "##" in text:
         text_content.append({"title":text.replace("##","")})
      elif "**" in text:
         text_content.append({"sub-heading":text.replace("**","")})
      else:
         text_content.append({"description":text})

   return text_content, loaded_ai


def get_category(topic_title,loaded_ai):
   resp = loaded_ai.send_message(f"Just Send the category name which this topic '{topic_title}' falls into. The category name should be only from these 9 categories. International, Business, Science, Technology, Lifestyle, Sports, Politics, Entertainment and Environment. Just send the category name, no additional information.")
   return resp.text
#text_content = [{'title': '  Beyond the Maple Syrup: Exploring the Current USCanada Relationship '}, {'description': ''}, {'description': 'The US and Canada, two nations deeply intertwined by shared history, geography, and culture, are currently experiencing a complex period in their bilateral relationship. While the two remain close allies, recent developments have brought tensions to the forefront, prompting questions about the future of their partnership. '}, {'description': ''}, {'sub-heading': "1. The Trade Conundrum: Navigating NAFTA's Legacy"}, {'description': ''}, {'description': 'The renegotiated USMexicoCanada Agreement (USMCA), replacing the North American Free Trade Agreement (NAFTA), has been a source of friction. While touted as a modernization of trade, USMCA has faced criticism from Canadian businesses and policymakers, particularly concerning provisions on dispute resolution and auto manufacturing. '}, {'description': ''}, {'description': 'The ongoing dispute over lumber tariffs further complicates the trade picture, with the US imposing tariffs on Canadian softwood lumber, citing unfair competition. Canada, in turn, has retaliated with tariffs on US goods, fueling a trade war that threatens to damage the economies of both nations.'}, {'description': ''}, {'sub-heading': '2. Energy Disputes: A Pipeline of Tensions'}, {'description': ''}, {'description': 'The proposed Keystone XL pipeline, designed to transport oil from Canada to the US, has become a symbol of the ongoing energy disputes between the two countries. Environmental concerns and political opposition in the US have stalled the project, leading to heightened tensions with Canada, who views the pipeline as crucial for its energy sector. '}, {'description': ''}, {'description': "Beyond Keystone XL, disagreements over energy policies, including the US's withdrawal from the Paris Climate Agreement, have created further divisions. "}, {'description': ''}, {'sub-heading': '3. Immigration and Asylum: A Test of Cooperation'}, {'description': ''}, {'description': 'The issue of immigration and asylum seekers at the USCanada border has become increasingly contentious. The Trump administration\'s "Remain in Mexico" policy, forcing asylum seekers to wait in Mexico while their cases are processed in the US, has led to a surge in asylum claims at the CanadaUS border. This influx has strained resources and exposed differences in immigration policies.'}, {'description': ''}, {'description': 'The differing approaches to immigration highlight the complex challenges of managing migration flows across a shared border, pushing the two countries to navigate a delicate balance between security and humanitarian concerns. '}, {'description': ''}, {'sub-heading': '4. The Impact of US Politics: A Shifting Landscape'}, {'description': ''}, {'description': 'The rise of political polarization in the US has had a noticeable impact on the USCanada relationship. The Trump administration\'s "America First" policies and its confrontational approach to international partnerships have led to a degree of uncertainty and apprehension in Canada. '}, {'description': ''}, {'description': "The US's withdrawal from international agreements, its imposition of tariffs on Canadian goods, and its rhetoric on immigration have fueled concerns about the future of the two nations' alliance. "}, {'description': ''}, {'sub-heading': '5. Beyond the Headlines: A Foundation of Shared Interests'}, {'description': ''}, {'description': 'Despite these challenges, the US and Canada remain deeply interconnected through shared history, culture, and economic interdependence.  Close cooperation on issues like security, defense, and environmental protection continues to be a cornerstone of the bilateral relationship. '}, {'description': ''}, {'description': 'The two countries also share a common commitment to democratic values and institutions. While current tensions may cast a shadow, the foundation of their partnership remains strong.'}, {'description': ''}, {'sub-heading': '6. Looking Ahead: Navigating Uncertainty'}, {'description': ''}, {'description': "The USCanada relationship is entering a new era, marked by uncertainty and the need for a renewed commitment to cooperation. The Biden administration's focus on restoring international alliances offers hope for a more collaborative approach, but significant challenges remain. "}, {'description': ''}, {'description': 'The two countries will need to find ways to address their differences on trade, energy, and immigration while fostering a spirit of dialogue and compromise.  The future of their partnership depends on the ability of both nations to overcome their differences and find common ground. '}, {'description': ''}]

def get_meta_description(topic_title, trending_keyword,loaded_ai):
   resp = loaded_ai.send_message(f"Give a small meta description for SEO on this topic '{topic_title}' by including this '{trending_keyword}' keyword into it. Just send the meta description, no additional information.")
   return resp.text

def get_category_id(category_name):
   if "Sports" in category_name:
      return "02de8f88-4ac0-4170-a5e7-8fc47c052bd1"
   elif "International" in category_name:
      return "c5f29c70-276b-4479-add3-f2710a2e18c7"
   elif "Business" in category_name:
      return "2b646854-54a0-4e16-a0aa-45e445fec3a9"
   elif "Lifestyle" in category_name:
      return "985685fb-4f7d-428f-af10-4dcbf99b8acd"
   elif "Technology" in category_name:
      return "5c96bee8-e5e6-4aa6-9dab-749598d41ff5"
   elif "Environment" in category_name:
      return "2d360ce1-bcf8-45ed-90d5-f6d40204309c"
   elif "Science" in category_name:
      return "51a874ad-ca93-467f-99e6-16c8c664d1fc"
   elif "Entertainment" in category_name:
      return "75c77bc1-978e-494b-a7be-678665c2e76e"
   elif "Politics" in category_name:
      return "5f328129-b5e1-4411-9660-9fee38b9e859"

#print(get_category_id("Politics"))
#print(get_category("Eagles vs Ravens: Preseason Clash Ends in Dramatic Fashion"))
#print(get_meta_description("Eagles vs Ravens: Preseason Clash Ends in Dramatic Fashion", "McCarthy"))

#print(get_ai_content('google'))