from pytrends.request import TrendReq

# Create a TrendReq object
pytrends = TrendReq(hl='en-US', tz=360, geo="GLOBAL")

trending_searches = []

def get_trending_searches():
    countries_list2 = ['argentina','australia','austria','belgium','canada','colombia','denmark','egypt','finland','france','greece','hong_kong']
    countries_list3 = ['indonesia','ireland','israel','japan','kenya','malaysia','mexico','nigeria','norway','poland','portugal','romania']
    countries_list4 = ['russia','saudi_arabia','south_korea','sweden','switzerland','taiwan','thailand','vietnam']
    countries_list = ['united_states','brazil','united_kingdom','india','germany','italy','singapore','south_africa','ukraine','netherlands']+countries_list2+countries_list3+countries_list4
    
    # Get trending searches in real-time (US region as an example)
    
    for country in countries_list:
        country_trending_searches = pytrends.trending_searches(pn=country)[0].tolist()
        for trend in country_trending_searches:
            trending_searches.append(trend)

    return trending_searches

#country_trending_searches = pytrends.trending_searches(pn="poland")[0].tolist()
#print(country_trending_searches)