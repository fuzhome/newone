import random
from duckduckgo_search import DDGS

def get_random_image_url(keyword):
    # Search for images using the keyword
    results = DDGS().images(keywords=keyword, max_results=18)

    # Filter images by size
    #filtered_images = [img for img in results if min_size_kb * 1024 <= img['size'] <= max_size_kb * 1024]

    #if not filtered_images:
    #    return None

    # Select a random image
    random_image = random.choice(results)
    
    #random_image['image']   return real image url
    return random_image['thumbnail']

# Example usage
#keyword = "sunset"
#image_url = get_random_image_url(keyword)
#print(image_url)
