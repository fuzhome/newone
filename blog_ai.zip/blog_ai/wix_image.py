import requests
from requests.structures import CaseInsensitiveDict

from auth import create_token

def upload_to_wix(image_url):

    url = "https://www.wixapis.com/site-media/v1/files/import"

    headers = CaseInsensitiveDict()
    headers["Authorization"] = create_token()
    #headers["Authorization"] = "IST.eyJraWQiOiJQb3pIX2FDMiIsImFsZyI6IlJTMjU2In0.eyJkYXRhIjoie1wiaWRcIjpcImVhODkwYWI0LTlhOGEtNGM0MC1hMTQ0LWY3MTY2YzQ0OWE0OFwiLFwiaWRlbnRpdHlcIjp7XCJ0eXBlXCI6XCJhcHBsaWNhdGlvblwiLFwiaWRcIjpcIjY2NTVlNDBiLTg0OTYtNDhlNS1iMzkxLWFmMjk4NzQzNWI4M1wifSxcInRlbmFudFwiOntcInR5cGVcIjpcImFjY291bnRcIixcImlkXCI6XCIwOWRiNmEyOC1jY2FkLTRmYjktODQ3Mi0zMWQ2M2ZlNWY1ODlcIn19IiwiaWF0IjoxNzIzNzQzNzA3fQ.Dr95b_t6maRLntJIToiZUbWEoqZzvLhEt9YmCaiMsbByOP5FAFi0WRERf9WzenkZ7YTEIlwPjj6zfDpL2x8rc_fSjcsuf3dNTU_wW4bz9k2uC6_X3VVhDYhIFopt5r5GGffGUspe6p8XfGFzMyks0V9DdPjFMTr6E61MjKW8_dC1QoYRyBN22FqQNrfDQNo-WhZKMxFLQb2_D8HIaJmgrCQZsUkRUSLL1_2dgcSOQ-qEzj6dL5MKeVp9trNHXLSQLfZgZsw1AbVBdLlFDLOdbpR7VfcH8PrgRtitBv4rGhgizjr3OZNyNF6glxAivNHJLdrKiPImX7Xii1t-542kEQ" # api for everything access in wix
    #headers["Authorization"] = "TuZWzmjllmAArcQVhvqFtCoxMtLijSaUS0c6FlXb5iw.eyJpbnN0YW5jZUlkIjoiYWMwYTFhMWYtMjM5YS00MjYyLWEzNTktOGM3Zjc1ZTI4MmQyIiwiYXBwRGVmSWQiOiIyMmJlZjM0NS0zYzViLTRjMTgtYjc4Mi03NGQ0MDg1MTEyZmYiLCJtZXRhU2l0ZUlkIjoiYWMwYTFhMWYtMjM5YS00MjYyLWEzNTktOGM3Zjc1ZTI4MmQyIiwic2lnbkRhdGUiOiIyMDI0LTA4LTE2VDIzOjM4OjUxLjQxN1oiLCJ1aWQiOiIwOWRiNmEyOC1jY2FkLTRmYjktODQ3Mi0zMWQ2M2ZlNWY1ODkiLCJwZXJtaXNzaW9ucyI6Ik9XTkVSIiwiZGVtb01vZGUiOmZhbHNlLCJzaXRlT3duZXJJZCI6IjA5ZGI2YTI4LWNjYWQtNGZiOS04NDcyLTMxZDYzZmU1ZjU4OSIsInNpdGVNZW1iZXJJZCI6IjA5ZGI2YTI4LWNjYWQtNGZiOS04NDcyLTMxZDYzZmU1ZjU4OSIsImV4cGlyYXRpb25EYXRlIjoiMjAyNC0wOC0xN1QwMzozODo1MS40MTdaIiwibG9naW5BY2NvdW50SWQiOiIwOWRiNmEyOC1jY2FkLTRmYjktODQ3Mi0zMWQ2M2ZlNWY1ODkiLCJhb3IiOnRydWV9"  
    
    headers["Content-Type"] = "application/json"

    data = '''
    {
    "url": "'''+image_url+'''",
    "mediaType": "IMAGE"
    }
    '''

    resp = requests.post(url, headers=headers,data=data)
    #print(resp.status_code, resp.text)
    return resp.json()['file']['id']


#print(upload_to_wix("https://static01.nyt.com/images/2024/08/13/opinion/13wu/13wu-videoSixteenByNineJumbo1600.jpg"))