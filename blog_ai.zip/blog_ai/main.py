
from google_image import get_random_image_url
from gemini import get_ai_content, get_category, get_meta_description, get_category_id
from content import get_rich_content_node_list
from wix_post import create_blog_post
from time import sleep
from trends import get_trending_searches


while True:
    trending_searches = list(set(get_trending_searches()))
    #trending_searches = ['張國煒']
    #trending_searches = ["Ilhan Omar"]
    not_posted_keywords = []

    all_posted = False
    while all_posted == False:
        for trending_keyword in trending_searches:
            try:
                #print("Image loaded")
                ai_content = get_ai_content(trending_keyword)
                #print(ai_content)
                ai_content_list = ai_content[0]
                loaded_ai = ai_content[1]
                image_url = get_random_image_url(trending_keyword)
                
                rich_content_node_list = get_rich_content_node_list(trending_keyword,image_url,ai_content_list)
                title = ai_content_list[0]['title'][1:]  # [1:] cuts first space character
                #print("AI Content loaded")
                category_id = get_category_id(get_category(title,loaded_ai))
                #print("Category loaded")
                meta_description = get_meta_description(title,trending_keyword,loaded_ai)
                #print("Meta Description loaded")
                post_id = create_blog_post(title,trending_keyword,category_id,meta_description,rich_content_node_list)

                print("Succesfully Posted",trending_keyword)
                
            except:
                not_posted_keywords.append(trending_keyword)
        if len(not_posted_keywords) <= 0:
            all_posted = True
            break
        trending_searches = not_posted_keywords
    sleep(3600)
