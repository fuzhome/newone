import requests
from requests.structures import CaseInsensitiveDict
import json
from datetime import datetime
from auth import create_token

url = "https://www.wixapis.com/blog/v3/draft-posts/"

headers = CaseInsensitiveDict()
headers["Content-Type"] = "application/json"
#headers["Authorization"] = "06aLCuZQUmMnZb2KU5E5HSWEF--OPqJbqYAGTCYXehM.eyJpbnN0YW5jZUlkIjoiYWMwYTFhMWYtMjM5YS00MjYyLWEzNTktOGM3Zjc1ZTI4MmQyIiwiYXBwRGVmSWQiOiIyMmJlZjM0NS0zYzViLTRjMTgtYjc4Mi03NGQ0MDg1MTEyZmYiLCJtZXRhU2l0ZUlkIjoiYWMwYTFhMWYtMjM5YS00MjYyLWEzNTktOGM3Zjc1ZTI4MmQyIiwic2lnbkRhdGUiOiIyMDI0LTA4LTE1VDE3OjQwOjAxLjUwNloiLCJ1aWQiOiIwOWRiNmEyOC1jY2FkLTRmYjktODQ3Mi0zMWQ2M2ZlNWY1ODkiLCJwZXJtaXNzaW9ucyI6Ik9XTkVSIiwiZGVtb01vZGUiOmZhbHNlLCJzaXRlT3duZXJJZCI6IjA5ZGI2YTI4LWNjYWQtNGZiOS04NDcyLTMxZDYzZmU1ZjU4OSIsInNpdGVNZW1iZXJJZCI6IjA5ZGI2YTI4LWNjYWQtNGZiOS04NDcyLTMxZDYzZmU1ZjU4OSIsImV4cGlyYXRpb25EYXRlIjoiMjAyNC0wOC0xNVQyMTo0MDowMS41MDZaIiwibG9naW5BY2NvdW50SWQiOiIwOWRiNmEyOC1jY2FkLTRmYjktODQ3Mi0zMWQ2M2ZlNWY1ODkiLCJhb3IiOnRydWV9"
headers["Authorization"] = create_token()

def create_blog_post(title, seo_keyword, category_id, meta_description, rich_content_node_list):
    created_at = datetime.utcnow().isoformat() + 'Z'
    
    data = json.dumps({
        "draftPost": {
            "richContent": {
                "nodes": json.loads(rich_content_node_list),
                "metadata": {
                    "version": 1,
                    "createdTimestamp": created_at,
                    "updatedTimestamp": created_at,
                    "id": "527d9b70-35c9-4bde-9488-455d29be225e"
                },
                "documentStyle": {}
            },
            "commentingEnabled": True,
            "media": {
                "custom": False,
                "displayed": True
            },
            "title": title,
            "categoryIds": [category_id],
            "seoData": {
                "tags": [{"type": "meta", "props": {"name": "description", "content": meta_description}}],
                "settings": {"preventAutoRedirect": False, "keywords": [{"isMain": True, "term": seo_keyword}]}
            },
            "hashtags": [],
            "heroImage": None,
            "tagIds": []
        },
        "fieldsets": ["RICH_CONTENT", "TRANSLATIONS"],
        "saveType": "AUTO_SAVE",
        "shouldPublish": True
    })

    resp = requests.post(url, headers=headers, data=data)

    if resp.status_code == 200:
        post = resp.json()['draftPost']
        post_id = post['id']
        return post_id
    else:
        print(f"Failed to create post: {resp.status_code}")
        print(resp.text)
        return None

# Example usage:
#rich_list = [{"type": "PARAGRAPH", "id": "1space", "nodes": [], "paragraphData": {}}, {"type": "IMAGE", "id": "2image", "nodes": [], "imageData": {"containerData": {"width": {"custom": "368"}, "alignment": "CENTER"}, "image": {"src": {"id": "09db6a_c67c6218555d44de9de5bdcfb1e4a09e~mv2.jpg"}, "width": 474, "height": 266}, "altText": "Ilhan Omar"}}, {"type": "PARAGRAPH", "id": "2space", "nodes": [], "paragraphData": {}}, {"type": "PARAGRAPH", "id": "3space", "nodes": [], "paragraphData": {}}, {"type": "PARAGRAPH", "id": "4", "nodes": [{"type": "TEXT", "id": "", "nodes": [], "textData": {"text": "", "decorations": []}}], "paragraphData": {"textStyle": {"textAlignment": "AUTO"}}}, {"type": "PARAGRAPH", "id": "27", "nodes": [{"type": "TEXT", "id": "", "nodes": [], "textData": {"text": "Ilhan Omar, the first Somali American elected to Congress, has become a lightning rod for controversy since her election in 2018. Her outspokenness on issues like foreign policy, social justice, and the treatment of Muslims has drawn both fervent support and fierce criticism. ", "decorations": []}}], "paragraphData": {"textStyle": {"textAlignment": "AUTO"}}}, {"type": "PARAGRAPH", "id": "52", "nodes": [{"type": "TEXT", "id": "", "nodes": [], "textData": {"text": "", "decorations": []}}], "paragraphData": {"textStyle": {"textAlignment": "AUTO"}}}, {"type": "HEADING", "id": "57", "nodes": [{"type": "TEXT", "id": "", "nodes": [], "textData": {"text": "1.  A Voice for Marginalized Communities:", "decorations": []}}], "headingData": {"level": 4, "textStyle": {"textAlignment": "AUTO"}}}, {"type": "PARAGRAPH", "id": "14", "nodes": [{"type": "TEXT", "id": "", "nodes": [], "textData": {"text": "", "decorations": []}}], "paragraphData": {"textStyle": {"textAlignment": "AUTO"}}}, {"type": "PARAGRAPH", "id": "40", "nodes": [{"type": "TEXT", "id": "", "nodes": [], "textData": {"text": "Omar's background as a Somali refugee who fled civil war in her homeland shapes her political outlook. She champions issues affecting marginalized communities, including the fight for immigrant rights, the struggle against Islamophobia, and the pursuit of economic justice. Her advocacy for social change has resonated with many, solidifying her image as a champion of the downtrodden.", "decorations": []}}], "paragraphData": {"textStyle": {"textAlignment": "AUTO"}}}, {"type": "PARAGRAPH", "id": "16", "nodes": [{"type": "TEXT", "id": "", "nodes": [], "textData": {"text": "", "decorations": []}}], "paragraphData": {"textStyle": {"textAlignment": "AUTO"}}}, {"type": "HEADING", "id": "10", "nodes": [{"type": "TEXT", "id": "", "nodes": [], "textData": {"text": "2.  A Critic of Foreign Policy:", "decorations": []}}], "headingData": {"level": 4, "textStyle": {"textAlignment": "AUTO"}}}, {"type": "PARAGRAPH", "id": "83", "nodes": [{"type": "TEXT", "id": "", "nodes": [], "textData": {"text": "", "decorations": []}}], "paragraphData": {"textStyle": {"textAlignment": "AUTO"}}}, {"type": "PARAGRAPH", "id": "67", "nodes": [{"type": "TEXT", "id": "", "nodes": [], "textData": {"text": "Omar has been a vocal critic of US foreign policy, particularly its involvement in the Middle East. She has called for the US to withdraw from Yemen and has denounced the use of drone strikes. Her stance on foreign policy has alienated some, particularly those who believe in a strong military presence globally. However, her views align with the growing anti war sentiment amongst younger generations, particularly those who grew up witnessing the repercussions of US interventions abroad.", "decorations": []}}], "paragraphData": {"textStyle": {"textAlignment": "AUTO"}}}, {"type": "PARAGRAPH", "id": "69", "nodes": [{"type": "TEXT", "id": "", "nodes": [], "textData": {"text": "", "decorations": []}}], "paragraphData": {"textStyle": {"textAlignment": "AUTO"}}}, {"type": "HEADING", "id": "69", "nodes": [{"type": "TEXT", "id": "", "nodes": [], "textData": {"text": "3.  The Target of Political Attacks:", "decorations": []}}], "headingData": {"level": 4, "textStyle": {"textAlignment": "AUTO"}}}, {"type": "PARAGRAPH", "id": "10", "nodes": [{"type": "TEXT", "id": "", "nodes": [], "textData": {"text": "", "decorations": []}}], "paragraphData": {"textStyle": {"textAlignment": "AUTO"}}}, {"type": "PARAGRAPH", "id": "32", "nodes": [{"type": "TEXT", "id": "", "nodes": [], "textData": {"text": "Omar has faced numerous attacks from Republicans and right wing media outlets. These attacks have often centered on her religious beliefs, her ethnicity, and her perceived anti Israel stance. In 2019, she was accused of anti Semitism after making comments about AIPAC, a pro Israel lobbying group. While Omar apologized for the phrasing of her comments, the incident sparked a national debate about the definition of anti Semitism and the role of Islamophobia in American politics.", "decorations": []}}], "paragraphData": {"textStyle": {"textAlignment": "AUTO"}}}, {"type": "PARAGRAPH", "id": "58", "nodes": [{"type": "TEXT", "id": "", "nodes": [], "textData": {"text": "", "decorations": []}}], "paragraphData": {"textStyle": {"textAlignment": "AUTO"}}}, {"type": "HEADING", "id": "79", "nodes": [{"type": "TEXT", "id": "", "nodes": [], "textData": {"text": "4.  A Champion of Social Justice:", "decorations": []}}], "headingData": {"level": 4, "textStyle": {"textAlignment": "AUTO"}}}, {"type": "PARAGRAPH", "id": "85", "nodes": [{"type": "TEXT", "id": "", "nodes": [], "textData": {"text": "", "decorations": []}}], "paragraphData": {"textStyle": {"textAlignment": "AUTO"}}}, {"type": "PARAGRAPH", "id": "61", "nodes": [{"type": "TEXT", "id": "", "nodes": [], "textData": {"text": "Omar has been a vocal advocate for progressive causes, including Medicare for All, tuition free college, and the Green New Deal. She has also been a leading voice in the fight for racial justice, speaking out against police brutality and systemic racism. Her support for these issues has earned her the admiration of many progressives, but it has also drawn criticism from those who believe her policies are too radical.", "decorations": []}}], "paragraphData": {"textStyle": {"textAlignment": "AUTO"}}}, {"type": "PARAGRAPH", "id": "65", "nodes": [{"type": "TEXT", "id": "", "nodes": [], "textData": {"text": "", "decorations": []}}], "paragraphData": {"textStyle": {"textAlignment": "AUTO"}}}, {"type": "HEADING", "id": "2", "nodes": [{"type": "TEXT", "id": "", "nodes": [], "textData": {"text": "5.  A Controversial Figure:", "decorations": []}}], "headingData": {"level": 4, "textStyle": {"textAlignment": "AUTO"}}}, {"type": "PARAGRAPH", "id": "2", "nodes": [{"type": "TEXT", "id": "", "nodes": [], "textData": {"text": "", "decorations": []}}], "paragraphData": {"textStyle": {"textAlignment": "AUTO"}}}, {"type": "PARAGRAPH", "id": "15", "nodes": [{"type": "TEXT", "id": "", "nodes": [], "textData": {"text": "Omar's outspoken nature and her willingness to challenge the status quo have made her a controversial figure. Her critics accuse her of being divisive and extreme. Her supporters, however, view her as a courageous and principled leader who is fighting for the rights of all Americans.", "decorations": []}}], "paragraphData": {"textStyle": {"textAlignment": "AUTO"}}}, {"type": "PARAGRAPH", "id": "52", "nodes": [{"type": "TEXT", "id": "", "nodes": [], "textData": {"text": "", "decorations": []}}], "paragraphData": {"textStyle": {"textAlignment": "AUTO"}}}, {"type": "HEADING", "id": "19", "nodes": [{"type": "TEXT", "id": "", "nodes": [], "textData": {"text": "6.  A Symbol of Change:", "decorations": []}}], "headingData": {"level": 4, "textStyle": {"textAlignment": "AUTO"}}}, {"type": "PARAGRAPH", "id": "1", "nodes": [{"type": "TEXT", "id": "", "nodes": [], "textData": {"text": "", "decorations": []}}], "paragraphData": {"textStyle": {"textAlignment": "AUTO"}}}, {"type": "PARAGRAPH", "id": "71", "nodes": [{"type": "TEXT", "id": "", "nodes": [], "textData": {"text": "Despite the controversy, Omar remains a symbol of hope for many. Her election to Congress represents a major shift in American politics, demonstrating the growing power of diverse voices and progressive ideals. Her story is a testament to the potential of marginalized communities to break down barriers and demand a seat at the table.", "decorations": []}}], "paragraphData": {"textStyle": {"textAlignment": "AUTO"}}}, {"type": "PARAGRAPH", "id": "19", "nodes": [{"type": "TEXT", "id": "", "nodes": [], "textData": {"text": "", "decorations": []}}], "paragraphData": {"textStyle": {"textAlignment": "AUTO"}}}, {"type": "PARAGRAPH", "id": "48", "nodes": [{"type": "TEXT", "id": "", "nodes": [], "textData": {"text": "As Ilhan Omar continues to navigate the political landscape, her story will undoubtedly continue to unfold. Whether she becomes a transformative figure or a fading footnote in American history, her impact on the political conversation is undeniable. She stands as a symbol of the ongoing struggle for justice, equality, and representation for all. ", "decorations": []}}], "paragraphData": {"textStyle": {"textAlignment": "AUTO"}}}, {"type": "PARAGRAPH", "id": "3", "nodes": [{"type": "TEXT", "id": "", "nodes": [], "textData": {"text": "", "decorations": []}}], "paragraphData": {"textStyle": {"textAlignment": "AUTO"}}}]
#rich_list_str = json.dumps(rich_list)
#post_id = create_blog_post("Sample Title", "sample-keyword", "c5f29c70-276b-4479-add3-f2710a2e18c7", "Sample description", rich_list_str)
#print(f"Post ID: {post_id}")
